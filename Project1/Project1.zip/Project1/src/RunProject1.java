/*
    This will be used to run Kiosk.
    @Tenzin Norden, @Vedant Mehta
*/

class RunProject1 {

   public static void main(String[] args) {
      new Kiosk().run();
   }
}
